package Examen1OCunado;
/**
 * Created by 48089748z on 11/12/15.
 */
public class MapVacio extends Exception {}
