package Examen1OCunado;

/**
 * Created by 48089748z on 11/12/15.
 */
enum DiaSemana{LUNES, MARTES, MIERCOLES, JUEVES, VIERNES, SABADO, DOMINGO}
